/*
  У вас есть массив названий пицц вашего конкурента.
  Создайте скрипт с циклом, который будет проверять ваш набор названий пицц (массив) 
  и набор названий пицц конкурента (массив), пицц которых нет у конкурента присвойте в переменную "resultUnique" (массив).
  Если все ваши пиццы есть у конкурента результатом будет "null" присвойте в переменную "resultNull".

  Скрипт не должен зависеть от регистра, в котором указаны названия пицц у вас и конкурента
  Воспользуйтесь наборами пицц, что приведены ниже.

  Пиццы:
  const competitorPizzas = ['Peperoni', 'Caprichosa', 'Diablo', '4 cheeses', 'hawai']
  const myPizzasT1 = ['Peperoni', 'Margherita', 'Diablo', 'Vegetarian'];
  const myPizzasT2 = ['Peperoni', 'Caprichosa', 'Diablo', '4 cheeses', 'hawai'];
*/

let resultUnique = [];
let resultNull;
const competitorPizzas = ['Peperoni', 'Caprichosa', 'Diablo', '4 cheeses', 'hawai'];
const myPizzasT1 = ['Peperoni', 'Margherita', 'Diablo', 'Vegetarian'];
const myPizzasT2 = ['Peperoni', 'Caprichosa', 'Diablo', '4 cheeses', 'hawai'];
for (let i = 0; i < myPizzasT1.length; i++) {
  let samePizza = false;
  for (let j = 0; j < competitorPizzas.length; j++) {
    if (myPizzasT1[i].includes(competitorPizzas[j])) {
      samePizza = true;
      break;
    }
  }
  if (!samePizza) {
    resultUnique.push(myPizzasT1[i]);
  }
}
if (resultUnique.length === 0) resultNull = null;

let resultUnique2 = [];
for (let i = 0; i < myPizzasT2.length; i++) {
  let samePizza = false;
  for (let j = 0; j < competitorPizzas.length; j++) {
    if (myPizzasT2[i].includes(competitorPizzas[j])) {
      samePizza = true;
      break;
    }
  }
  if (!samePizza) {
    resultUnique2.push(myPizzasT2[i]);
  }
}
if (resultUnique2.length === 0) resultNull = null;

export { resultNull, resultUnique };
