/*

 - Создайте переменную salary со значением 1000
  - Создайте переменную grade, которая должна получить значение "middle" если salary больше или равна 1000, и значение "junior" - если меньше
  */
const salary = 1000;
const grade = salary < 1000 ? 'junior' : 'middle';
console.log(grade);
